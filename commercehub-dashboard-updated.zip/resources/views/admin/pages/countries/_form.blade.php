
<div class="form-row">
    <div class="form-group col-md-6">
        <label for="name_ar">
            {{ __('dashboard.Arabic name') }}
            <span class="text-danger">*</span>
        </label>

        <input
            type="text"
            name="name_ar"
            id="name_ar"
            class="form-control"
            value="{{ old('name_ar', $country->name_ar ?? '') }}"
            required
        >

        @error('name_ar')
        <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="form-group col-md-6">
        <label for="name_en">
            {{ __('dashboard.English name') }}
            <span class="text-danger">*</span>
        </label>

        <input
            type="text"
            name="name_en"
            id="name_en"
            class="form-control"
            value="{{ old('name_en', $country->name_en ?? '') }}"
            required
        >

        @error('name_en')
        <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="form-group col-md-6">
        <label for="code">
            {{ __('dashboard.Country code (2 letters)') }}
            <span class="text-danger">*</span>
        </label>

        <input
            type="text"
            name="code"
            id="code"
            class="form-control"
            value="{{ old('code', $country->code ?? '') }}"
            maxlength="2"
            required
        >

        @error('code')
        <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="form-group col-md-6">
        <label for="currency_id">
            {{ __('dashboard.Currency') }}
            <span class="text-danger">*</span>
        </label>

        <select name="currency_id" id="currency_id" class="form-control" required>
            <option value="">{{ __('dashboard.Select currency') }}</option>

            @foreach($currencies as $option)
                <option
                    value="{{ $option->id }}"
                    {{ (string) old('currency_id', $country->currency_id ?? '') === (string) $option->id ? 'selected' : '' }}
                >
                    {{ $option->name }} ({{ $option->code }})
                </option>
            @endforeach
        </select>

        @error('currency_id')
        <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="form-group col-md-6">
        <label for="is_active">{{ __('dashboard.Status') }}</label>

        <div class="custom-control custom-checkbox">
            <input
                type="checkbox"
                name="is_active"
                value="1"
                id="is_active"
                class="custom-control-input"
                {{ old('is_active', $country->is_active ?? true) ? 'checked' : '' }}
            >

            <label class="custom-control-label" for="is_active">
                {{ __('dashboard.Active') }}
            </label>
        </div>
    </div>
</div>

<div class="text-center mt-3">
    <button type="submit" class="btn btn-primary">
        {{ $isEdit ? __('dashboard.Update') : __('dashboard.Create') }}
    </button>

    <a href="{{ route('admin.countries.index') }}" class="btn btn-secondary ml-2">
        {{ __('dashboard.Cancel') }}
    </a>
</div>
