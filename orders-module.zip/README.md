# Orders + Coupons + Bloggers module - how to install

1. Copy the folders into the project (app, config, database, lang, resources). Keep the same paths.
2. Open routes/orders.php and paste its lines inside your admin route group
   (add the 3 `use` lines of the controllers at the top of your routes file).
3. If you already ran the first orders migrations, roll them back first
   (php artisan migrate:rollback --step=2) - the orders/order_items files were replaced by new versions.
4. Run: php artisan migrate
5. Edit config/orders.php to list your payment gateways.

## Assumptions (change them if your project is different)
- Models: Product, ProductVariant, Store, Category  (App\Models)
- Tables: products, product_variants, stores, categories
- Product columns: store_id, category_id, sku, name_ar, name_en, price, stock, is_sale, sale_price, has_variants, status
- Category columns: parent_id, name_ar, name (same as your product form)
- Variant columns: product_id, sku, price, discount_price, quantity ; relation values() with value_en
- Route names start with "admin."
- Layout: layouts.admin with @yield('content')

## How the flow works
- Coupon = discount + categories (+ optional blogger with a commission).
- Order create: OrderService -> CouponService (discount + commission), all in one transaction.
- Commission: pending (order created) -> earned (delivered) -> cancelled (order cancelled or returned).
- Cancel is allowed only before shipping. Return is allowed after shipping.
- Payment: cod / online (gateway from config) / bank_transfer. A gateway webhook can call OrderService::updatePayment().

## Seeders (development data)
- BloggerSeeder: 3 bloggers (one inactive).
- CouponSeeder: 8 coupons (general, blogger, expired, not started, inactive, inactive blogger). It calls BloggerSeeder.
- Run: php artisan db:seed --class=CouponSeeder   (categories must exist first)
- Or add `$this->call(CouponSeeder::class);` to DatabaseSeeder.
