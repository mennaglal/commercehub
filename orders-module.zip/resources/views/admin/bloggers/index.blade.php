{{-- Change 'layouts.admin' / 'content' to your real admin layout names. --}}
@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">{{ __('bloggers.title') }}</h4>
        <a href="{{ route('admin.bloggers.create') }}" class="btn btn-primary">{{ __('bloggers.add') }}</a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                <tr>
                    <th>{{ __('bloggers.columns.name') }}</th>
                    <th>{{ __('bloggers.columns.phone') }}</th>
                    <th>{{ __('bloggers.columns.email') }}</th>
                    <th>{{ __('bloggers.columns.coupons') }}</th>
                    <th>{{ __('bloggers.columns.status') }}</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                @forelse($bloggers as $blogger)
                    <tr>
                        <td>{{ $blogger->name }}</td>
                        <td>{{ $blogger->phone ?? '-' }}</td>
                        <td>{{ $blogger->email ?? '-' }}</td>
                        <td>{{ $blogger->coupons_count }}</td>
                        <td>
                            <span class="badge bg-{{ $blogger->status ? 'success' : 'secondary' }}">
                                {{ $blogger->status ? __('bloggers.active') : __('bloggers.inactive') }}
                            </span>
                        </td>
                        <td class="text-end">
                            <a href="{{ route('admin.bloggers.show', $blogger) }}" class="btn btn-sm btn-outline-secondary">{{ __('orders.fields.view') }}</a>
                            <a href="{{ route('admin.bloggers.edit', $blogger) }}" class="btn btn-sm btn-outline-primary">{{ __('bloggers.edit') }}</a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="6" class="text-center text-muted py-4">{{ __('bloggers.empty') }}</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">{{ $bloggers->links() }}</div>
</div>
@endsection
