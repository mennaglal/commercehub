{{-- Change 'layouts.admin' / 'content' to your real admin layout names. --}}
@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">{{ __('coupons.title') }}</h4>
        <a href="{{ route('admin.coupons.create') }}" class="btn btn-primary">{{ __('coupons.add') }}</a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                <tr>
                    <th>{{ __('coupons.columns.code') }}</th>
                    <th>{{ __('coupons.columns.discount') }}</th>
                    <th>{{ __('coupons.columns.categories') }}</th>
                    <th>{{ __('coupons.columns.owner') }}</th>
                    <th>{{ __('coupons.columns.commission') }}</th>
                    <th>{{ __('coupons.columns.usage') }}</th>
                    <th>{{ __('coupons.columns.validity') }}</th>
                    <th>{{ __('coupons.columns.status') }}</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                @forelse($coupons as $coupon)
                    <tr>
                        <td><strong>{{ $coupon->code }}</strong></td>
                        <td>
                            {{ $coupon->type === 'percentage' ? rtrim(rtrim($coupon->value, '0'), '.') . '%' : number_format($coupon->value, 2) }}
                        </td>
                        <td>{{ $coupon->categories_count }}</td>
                        <td>{{ $coupon->blogger?->name ?? __('coupons.general') }}</td>
                        <td>
                            @if($coupon->blogger_id)
                                {{ $coupon->commission_type === 'percentage' ? rtrim(rtrim($coupon->commission_value, '0'), '.') . '%' : number_format($coupon->commission_value, 2) }}
                            @else
                                -
                            @endif
                        </td>
                        <td>{{ $coupon->used_count }} / {{ $coupon->usage_limit ?? __('coupons.unlimited') }}</td>
                        <td>
                            <small>
                                {{ $coupon->starts_at?->format('Y-m-d') ?? '...' }}
                                &rarr;
                                {{ $coupon->expires_at?->format('Y-m-d') ?? '...' }}
                            </small>
                        </td>
                        <td>
                            <span class="badge bg-{{ $coupon->status ? 'success' : 'secondary' }}">
                                {{ $coupon->status ? __('coupons.active') : __('coupons.inactive') }}
                            </span>
                        </td>
                        <td>
                            <a href="{{ route('admin.coupons.edit', $coupon) }}" class="btn btn-sm btn-outline-primary">{{ __('coupons.edit') }}</a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="9" class="text-center text-muted py-4">{{ __('coupons.empty') }}</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">{{ $coupons->links() }}</div>
</div>
@endsection
