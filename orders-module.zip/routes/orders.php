<?php

// Paste these lines inside your existing admin route group
// (the one that already has the admin middleware and the "admin." name prefix),
// and add at the top of that file:
//   use App\Http\Controllers\Admin\BloggerController;
//   use App\Http\Controllers\Admin\CouponController;
//   use App\Http\Controllers\Admin\OrderController;
//
// "can:xxx" works with Spatie permissions out of the box (no middleware alias needed).
// Keep the "create" routes BEFORE the routes that have a {parameter}.

/* ---------------- Orders ---------------- */
Route::get('orders', [OrderController::class, 'index'])->middleware('can:orders.view')->name('orders.index');
Route::get('orders/create', [OrderController::class, 'create'])->middleware('can:orders.create')->name('orders.create');
Route::post('orders', [OrderController::class, 'store'])->middleware('can:orders.create')->name('orders.store');
Route::get('orders/{order}', [OrderController::class, 'show'])->middleware('can:orders.view')->name('orders.show');
Route::patch('orders/{order}/status', [OrderController::class, 'updateStatus'])->middleware('can:orders.update')->name('orders.status');
Route::patch('orders/{order}/delivery', [OrderController::class, 'updateDelivery'])->middleware('can:orders.update')->name('orders.delivery');
Route::patch('orders/{order}/payment', [OrderController::class, 'updatePayment'])->middleware('can:orders.update')->name('orders.payment');

/* ---------------- Coupons (no delete: deactivate them with the status) ---------------- */
Route::get('coupons', [CouponController::class, 'index'])->middleware('can:coupons.view')->name('coupons.index');
Route::get('coupons/create', [CouponController::class, 'create'])->middleware('can:coupons.create')->name('coupons.create');
Route::post('coupons', [CouponController::class, 'store'])->middleware('can:coupons.create')->name('coupons.store');
Route::get('coupons/{coupon}/edit', [CouponController::class, 'edit'])->middleware('can:coupons.update')->name('coupons.edit');
Route::put('coupons/{coupon}', [CouponController::class, 'update'])->middleware('can:coupons.update')->name('coupons.update');

/* ---------------- Bloggers ---------------- */
Route::get('bloggers', [BloggerController::class, 'index'])->middleware('can:bloggers.view')->name('bloggers.index');
Route::get('bloggers/create', [BloggerController::class, 'create'])->middleware('can:bloggers.create')->name('bloggers.create');
Route::post('bloggers', [BloggerController::class, 'store'])->middleware('can:bloggers.create')->name('bloggers.store');
Route::get('bloggers/{blogger}', [BloggerController::class, 'show'])->middleware('can:bloggers.view')->name('bloggers.show');
Route::get('bloggers/{blogger}/edit', [BloggerController::class, 'edit'])->middleware('can:bloggers.update')->name('bloggers.edit');
Route::put('bloggers/{blogger}', [BloggerController::class, 'update'])->middleware('can:bloggers.update')->name('bloggers.update');
