<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CouponRequest;
use App\Models\Blogger;
use App\Models\Category;
use App\Models\Coupon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class CouponController extends Controller
{
    public function index()
    {
        $coupons = Coupon::with('blogger:id,name')
            ->withCount('categories')
            ->latest()
            ->paginate(15);

        return view('admin.coupons.index', ['coupons' => $coupons]);
    }

    public function create()
    {
        return view('admin.coupons.create', $this->formData());
    }

    public function store(CouponRequest $request)
    {
        $data = $request->validated();

        // The coupon and its categories are saved together or not at all.
        DB::transaction(function () use ($data) {
            $coupon = Coupon::create($this->attributes($data));
            $coupon->categories()->sync($data['categories']);
        });

        return redirect()
            ->route('admin.coupons.index')
            ->with('success', __('coupons.messages.created'));
    }

    public function edit(Coupon $coupon)
    {
        $coupon->load('categories:id');

        return view('admin.coupons.edit', $this->formData() + ['coupon' => $coupon]);
    }

    public function update(CouponRequest $request, Coupon $coupon)
    {
        $data = $request->validated();

        DB::transaction(function () use ($data, $coupon) {
            $coupon->update($this->attributes($data));
            $coupon->categories()->sync($data['categories']);
        });

        return redirect()
            ->route('admin.coupons.index')
            ->with('success', __('coupons.messages.updated'));
    }

    // The coupon columns (everything except the categories).
    private function attributes(array $data): array
    {
        $attributes = Arr::except($data, ['categories']);

        // General coupon: no blogger, so no commission.
        if (empty($attributes['blogger_id'])) {
            $attributes['blogger_id'] = null;
            $attributes['commission_type'] = null;
            $attributes['commission_value'] = null;
        }

        return $attributes;
    }

    // Lists used by the form: categories as "Parent / Child" and the bloggers.
    private function formData(): array
    {
        $isArabic = app()->getLocale() === 'ar';
        $all = Category::orderBy('parent_id')->orderBy('id')->get()->keyBy('id');

        $name = fn ($category) => $isArabic ? $category->name_ar : $category->name;

        $categories = $all->map(function ($category) use ($all, $name) {
            $parent = $category->parent_id ? $all->get($category->parent_id) : null;

            return $parent ? $name($parent) . ' / ' . $name($category) : $name($category);
        })->sort()->all();   // [id => label]

        return [
            'categories' => $categories,
            'bloggers' => Blogger::orderBy('name')->get(['id', 'name']),
        ];
    }
}
