<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\BloggerRequest;
use App\Models\Blogger;
use App\Models\Order;

class BloggerController extends Controller
{
    public function index()
    {
        $bloggers = Blogger::withCount('coupons')->latest()->paginate(15);

        return view('admin.bloggers.index', ['bloggers' => $bloggers]);
    }

    public function create()
    {
        return view('admin.bloggers.create');
    }

    public function store(BloggerRequest $request)
    {
        $blogger = Blogger::create($request->validated());

        return redirect()
            ->route('admin.bloggers.show', $blogger)
            ->with('success', __('bloggers.messages.created'));
    }

    public function show(Blogger $blogger)
    {
        // Count and sum of the commissions, grouped by status (one query).
        $stats = Order::where('blogger_id', $blogger->id)
            ->selectRaw('commission_status, COUNT(*) as orders_count, SUM(commission_amount) as amount')
            ->groupBy('commission_status')
            ->get()
            ->keyBy('commission_status');

        $orders = Order::where('blogger_id', $blogger->id)->latest()->paginate(10);

        return view('admin.bloggers.show', [
            'blogger' => $blogger->load('coupons:id,blogger_id,code,status'),
            'stats' => $stats,
            'orders' => $orders,
        ]);
    }

    public function edit(Blogger $blogger)
    {
        return view('admin.bloggers.edit', ['blogger' => $blogger]);
    }

    public function update(BloggerRequest $request, Blogger $blogger)
    {
        $blogger->update($request->validated());

        return redirect()
            ->route('admin.bloggers.index')
            ->with('success', __('bloggers.messages.updated'));
    }
}
