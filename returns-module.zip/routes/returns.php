<?php

// Paste these lines inside your admin route group, near the orders routes, and add at the top:
//   use App\Http\Controllers\Admin\OrderReturnController;
// The permissions are checked in the controller (OrderReturnController::middleware()).

Route::get('returns', [OrderReturnController::class, 'index'])->name('returns.index');
Route::get('returns/{orderReturn}', [OrderReturnController::class, 'show'])->name('returns.show');
Route::patch('returns/{orderReturn}/status', [OrderReturnController::class, 'updateStatus'])->name('returns.status');

// Created from an order page.
Route::get('orders/{order}/returns/create', [OrderReturnController::class, 'create'])->name('orders.returns.create');
Route::post('orders/{order}/returns', [OrderReturnController::class, 'store'])->name('orders.returns.store');
