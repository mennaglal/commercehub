# Returns module (on top of your order-module)

## 1) Files in this zip
NEW:
- database/migrations: 3 files (order_items columns, order_returns, order_return_items)
- app/Models: OrderReturn, OrderReturnItem
- app/Services/ReturnService.php
- app/Http/Controllers/Admin/OrderReturnController.php
- app/Http/Requests/Admin/ReturnRequest.php
- resources/views/admin/pages/returns: index, create, show
- resources/views/admin/pages/orders/_returns.blade.php   (a partial for the order page)
- lang/en/returns.php, lang/ar/returns.php
- routes/returns.php   (paste into your admin group)

REPLACE (your files, edited - compare them with yours before copying):
- app/Models/Order.php        -> + returns() relation, + canBeReturned()
- app/Models/OrderItem.php    -> + discount_amount / commission_amount, + returnItems()
- app/Services/OrderService.php -> + split the discount and the commission between the items (allocate()),
                                   + guard: delivered -> returned is blocked if the order has customer returns
- app/Services/CouponService.php -> apply() also returns 'eligible_keys' (3 small changes)
  (this file was not in your zip: if you changed yours, apply only those 3 changes)

## 2) Steps
1. Copy the files. Replace the 4 files above.
2. config/orders.php: add   'return_days' => 14,
3. routes/admin.php: paste routes/returns.php inside the admin group + add the `use` line.
4. PermissionsSeeder: add   'returns' => ['view', 'create', 'update', 'refund'],
   then: php artisan db:seed --class=PermissionsSeeder   and give the permissions to the roles.
5. OrderController::show: add 'returns' to the ->load([...]) list.
6. orders/show.blade.php: add   @include('admin.pages.orders._returns')   before the "Totals" block.
7. Sidebar: add a "returns" section (see below) + the dashboard lang keys.
8. php artisan migrate

## 3) Sidebar section
[
    'id' => 'returns',
    'icon' => 'fe fe-rotate-ccw',
    'label' => __('dashboard.Returns'),
    'permission' => 'returns.view',
    'items' => [
        [
            'route' => 'admin.returns.index',
            'text' => __('dashboard.Show-Returns'),
            'permission' => 'returns.view',
        ],
    ],
],

dashboard lang keys:  en: 'Returns' => 'Returns', 'Show-Returns' => 'Show Returns'
                      ar: 'Returns' => 'المرتجعات', 'Show-Returns' => 'عرض المرتجعات'

## 4) Important
- Orders created BEFORE this update have discount_amount = 0 on their items, so a return of an old order
  that used a coupon would refund the full item price. In development: re-seed the orders.
  In production: run a backfill first, or block returns for those orders.
- Whole-order "returned" (delivery status, shipment that came back) is unchanged. Returns of delivered
  orders go through the returns system.
