<?php

// Paste in routes/api.php, and add at the top:
//   use App\Http\Controllers\Api\DeviceTokenController;
//   use App\Http\Controllers\Api\NotificationController;
// The apps must send the headers  Accept: application/json  and  Authorization: Bearer <token>.

Route::middleware('auth:sanctum')->group(function () {
    // The in-app inbox of the logged-in user (customer or vendor)
    Route::prefix('notifications')->group(function () {
        Route::get('/', [NotificationController::class, 'index']);
        Route::get('unread-count', [NotificationController::class, 'unreadCount']);
        Route::post('read-all', [NotificationController::class, 'markAllRead']);
        Route::post('{id}/read', [NotificationController::class, 'markRead']);
    });

    // Firebase: the app registers / removes the token of its phone
    Route::post('device-tokens', [DeviceTokenController::class, 'store'])->middleware('throttle:20,1');
    Route::post('device-tokens/unregister', [DeviceTokenController::class, 'destroy'])->middleware('throttle:20,1');
});
