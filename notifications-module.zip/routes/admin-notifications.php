<?php

// Paste inside your admin route group (the one with the "admin." name prefix), and add at the top:
//   use App\Http\Controllers\Admin\NotificationController;
// The permissions are checked inside the controller (notifications.view / notifications.send).
// Keep these lines in this order: "unread" and "send" must come before "{id}".

Route::get('notifications', [NotificationController::class, 'index'])->name('notifications.index');
Route::get('notifications/unread', [NotificationController::class, 'unread'])->name('notifications.unread');
Route::get('notifications/send', [NotificationController::class, 'compose'])->name('notifications.compose');
Route::post('notifications/send', [NotificationController::class, 'send'])->name('notifications.send');
Route::post('notifications/read-all', [NotificationController::class, 'readAll'])->name('notifications.read-all');
Route::get('notifications/{id}/open', [NotificationController::class, 'open'])->name('notifications.open');
Route::delete('notifications/{id}', [NotificationController::class, 'destroy'])->name('notifications.destroy');
