# Notifications + Firebase push (FCM)

Every notification is saved in the database (in-app inbox + the bell of the admin panel) and, when Firebase is
enabled, also pushed to the phones. You can use the inbox now and turn Firebase on later (FCM_ENABLED).

## 1) Files
NEW
- database/migrations: notifications, notification_broadcasts, device_tokens
- app/Models: DeviceToken, NotificationBroadcast
- app/Notifications/AppNotification.php          (ONE notification class for everything)
- app/Services/NotificationService.php           (the only place that sends: inbox + push)
- app/Services/PushService.php                   (Firebase)
- app/Jobs: SendPushJob, SendBroadcastJob        (background sending)
- app/Observers: OrderObserver, OrderReturnObserver, StoreObserver   (automatic notifications)
- app/Http/Controllers/Admin/NotificationController.php   (inbox + send a message)
- app/Http/Controllers/Api/NotificationController.php     (inbox of the app user)
- app/Http/Controllers/Api/DeviceTokenController.php      (the app registers its Firebase token)
- app/Http/Requests/Admin/BroadcastRequest.php
- app/Console/Commands/PushTestCommand.php       (php artisan push:test email)
- config/push.php
- resources/views/admin/pages/notifications: index, compose
- resources/views/admin/partials/notification-bell.blade.php
- lang/en + lang/ar notifications.php
- routes/admin-notifications.php, routes/api-notifications.php  (snippets)

## 2) Install (no Firebase yet)
1. Copy the files (same paths).
2. If you already have the "notifications" table (php artisan notifications:table), delete my first migration.
3. php artisan migrate
4. app/Providers/AppServiceProvider.php, in boot():
       \App\Models\Order::observe(\App\Observers\OrderObserver::class);
       \App\Models\OrderReturn::observe(\App\Observers\OrderReturnObserver::class);
       \App\Models\Store::observe(\App\Observers\StoreObserver::class);
5. Paste routes/admin-notifications.php in your admin group, and routes/api-notifications.php in routes/api.php.
6. Put the bell in the top bar:  @include('admin.partials.notification-bell')   (inside the <ul class="nav"> of the navbar)
7. Sidebar section (inside $sections) + dashboard lang keys:
       [
           'id' => 'notifications',
           'icon' => 'fe fe-bell',
           'label' => __('dashboard.Notifications'),
           'permission' => 'notifications.view',
           'items' => [
               ['route' => 'admin.notifications.index', 'text' => __('dashboard.Inbox'), 'permission' => 'notifications.view'],
               ['route' => 'admin.notifications.compose', 'text' => __('dashboard.Send-Notification'), 'permission' => 'notifications.send'],
           ],
       ],
       en: 'Notifications' => 'Notifications', 'Inbox' => 'Inbox', 'Send-Notification' => 'Send a notification'
       ar: 'Notifications' => 'الإشعارات', 'Inbox' => 'صندوق الإشعارات', 'Send-Notification' => 'إرسال إشعار'
8. Permissions: "notifications.view" and "notifications.send" already exist in your PermissionsSeeder.
   Give "notifications.view" to every role that should see the bell.
9. Queue (the notifications are sent in the background):
   - Development: QUEUE_CONNECTION=sync works immediately, nothing else to do.
   - Production: QUEUE_CONNECTION=database (or redis), then
         php artisan queue:table && php artisan migrate      (only if the jobs table does not exist)
         php artisan queue:work --tries=3                     (keep it alive with Supervisor)
     Without a running worker nothing is sent.

What you get automatically (no change in OrderService / ReturnService):
- New order            -> admins with orders.view, and the vendors that have products in the order
- Order status change  -> the vendors of the order
- New return request   -> admins with returns.view
- New store            -> admins with vendors.approve        (ASSUMPTION: stores.approval_status = 'pending')
- Store approved/rejected -> the store owner                  (values 'approved' / 'rejected')
- A message written by an admin -> customers / vendors / one user (screen: Send a notification)
To add a new notification: add its texts in lang/xx/notifications.php => events, then call
    $notifications->toAdmins('permission', $notifications->payload('type', 'event_key', [...], $url));
    $notifications->toUsers($users, ...)

## 3) Firebase setup (push to the phones)
1. console.firebase.google.com -> create a project -> add your Android / iOS app.
   iOS only: Project settings -> Cloud Messaging -> upload your APNs key.
2. Project settings -> Service accounts -> "Generate new private key". You get a JSON file.
   Save it in storage/app/firebase/service-account.json  (NOT in public/, and add it to .gitignore:
   this file gives full access to your Firebase project).
3. composer require kreait/laravel-firebase
   php artisan vendor:publish --provider="Kreait\Laravel\Firebase\ServiceProvider" --tag=config
   (written for kreait/laravel-firebase 5.x / 6.x: PushService uses sendMulticast. If you use a newer major
   version and sendMulticast is missing, only PushService.php needs a small change.)
4. .env:
       FIREBASE_CREDENTIALS=storage/app/firebase/service-account.json
       FCM_ENABLED=true
   then: php artisan config:clear
5. Test: log in once from the app (step 4 below), then
       php artisan push:test user@example.com
   "Firebase accepted the message for 1 device(s)" = everything works.

## 4) What the mobile app must do
Always send:  Accept: application/json  and  Authorization: Bearer <sanctum token>

1. After login (and every app start, and whenever Firebase gives a new token), register the token:
       POST /api/device-tokens
       { "token": "<FCM token>", "platform": "android" | "ios" | "web", "locale": "ar" | "en", "app_version": "1.0.3" }
2. On logout:
       POST /api/device-tokens/unregister      { "token": "<FCM token>" }
3. The inbox screen:
       GET  /api/notifications                 (paginated)
       GET  /api/notifications/unread-count
       POST /api/notifications/{id}/read
       POST /api/notifications/read-all
4. When the user taps a push, the app receives data: { "type": "order|return|store|broadcast|system", "url": "..." }.

Flutter example:
       final fcm = FirebaseMessaging.instance;
       await fcm.requestPermission();                       // Android 13+ and iOS ask the user
       final token = await fcm.getToken();
       await api.post('/device-tokens', {'token': token, 'platform': Platform.isIOS ? 'ios' : 'android', 'locale': 'ar'});
       fcm.onTokenRefresh.listen((t) => api.post('/device-tokens', {'token': t, 'platform': ..., 'locale': 'ar'}));

## 5) How it works, and why it is safe and fast
- One class (AppNotification) and one service (NotificationService): a new notification is a text + one call.
- Observers send the notifications AFTER the order transaction is saved: if the order fails, nothing is sent.
- Push is sent in the background in groups of 500 users (the Firebase limit per call), one message per
  language (every phone gets the text in its own language), and failed jobs are retried 3 times.
- A message written by an admin is saved and queued: the screen answers immediately even for 50,000 users.
  The users are read in chunks of 500 (no memory problem). Its "Recipients" number appears when the job finishes.
- Dead tokens (app uninstalled / token expired) are deleted automatically when Firebase reports them.
- A token belongs to ONE user (unique). A user keeps at most 10 devices. The token routes are throttled.
- An admin or an app user can only read, open and delete HIS OWN notifications.
- The admin screens redirect only inside your website, links in a message must be http(s), and the bell
  writes the text with textContent (no HTML injection).
- Optional cleanup of old tokens (routes/console.php):
      Schedule::call(fn () => \App\Models\DeviceToken::where('last_used_at', '<', now()->subDays(90))->delete())->daily();
